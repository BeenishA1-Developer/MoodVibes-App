package com.example.moodvibes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.moodvibes.ui.theme.MoodVibesTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MoodVibesTheme {
                MoodVibesApp()
            }
        }
    }
}

@Composable
fun MoodVibesApp() {
    var selectedMood by remember { mutableStateOf("Sad") }

    val moodData = mapOf(
        "Happy" to Pair("😊", Color(0xFF8E7CAB)),   // Light Yellow
        "Sad" to Pair("😢", Color(0xFF90CAF9)),     // Light Blue
        "Angry" to Pair("😡", Color(0xFF9B3F3F)),   // Light Red
        "Chill" to Pair("😎", Color(0xFFA5D6A7)),   // Light Green
        "Excited" to Pair("🤩", Color(0xFFFFCC80)), // Light Orange
        "Relax" to Pair("🤗", Color(0xFFB39DDB))    // Light Purple
    )

    val emoji = moodData[selectedMood]?.first ?: "😊"
    val bgColor = moodData[selectedMood]?.second ?: Color.White
    val message = when (selectedMood) {
        "Happy" -> "Keep spreading the joy!"
        "Sad" -> "It’s okay to feel down sometimes."
        "Angry" -> "Take a deep breath, it's gonna be okay."
        "Chill" -> "Just vibing, nice!"
        "Excited" -> "Let that energy shine!"
        "Relax" -> "Peace and calm, good choice."
        else -> ""
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = bgColor
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "How are you feeling today?", fontSize = 24.sp)

            val moods = listOf("Happy", "Sad", "Angry", "Chill", "Excited", "Relax")

            // 1st Row: First 3 moods
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                moods.take(3).forEach { mood ->
                    Button(
                        onClick = { selectedMood = mood },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedMood == mood) Color.Black else Color.LightGray,
                            contentColor = if (selectedMood == mood) Color.White else Color.Black
                        )
                    ) {
                        Text(text = mood)
                    }
                }
            }

            // 2nd Row: Last 3 moods
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                moods.drop(3).forEach { mood ->
                    Button(
                        onClick = { selectedMood = mood },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedMood == mood) Color.Black else Color.LightGray,
                            contentColor = if (selectedMood == mood) Color.White else Color.Black
                        )
                    ) {
                        Text(text = mood)
                    }
                }
            }

            Text(text = emoji, fontSize = 64.sp)
            Text(text = message, fontSize = 28.sp)
        }
    }
}
